using System;

namespace Breakout.BreakoutStates {
    public enum GameStateType {
        GameRunning,
        GamePaused,
        GameOver,
        MainMenu
    }
}


 


